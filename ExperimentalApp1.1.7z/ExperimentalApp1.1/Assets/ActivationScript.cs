﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ActivationScript : MonoBehaviour {

    public GameObject GameObject;
	// Use this for initialization
	void Start () {
        RotationScript script = GameObject.GetComponent<RotationScript>();
        script.enabled = !script.enabled;
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    
}
