﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Threading;
using System;
using System.Diagnostics;

public class LocalPony
{
    public int mode;
    public float[] quaternion;
}
public class RotationScript : MonoBehaviour {

    Thread ponyThread;
    float[] currentQuaternion;
    LocalPony pony;
    Stopwatch stopwatch;
    Vector3 acceleration = new Vector3(), gyroscope = new Vector3();

    public long timeInterval;

    //extern void ponyStart();
    //extern void ponyFinish();
    //extern double[] ponyQuaternion();


    //const float deltat = 1 / 250.0f; // sampling period in seconds (shown as 1 ms)
    const float gyroMeasError = 3.14159265358979f * (5.0f / 180.0f); //gyroscope measurement error in rad / s(shown as 5 deg / s)
    readonly float beta = (float)Math.Sqrt(3.0f / 4.0f) * gyroMeasError; // compute beta
    const float M_PI = 3.14159265358979323846f;


    private void OnEnable()
    {
        //ponyThread = new Thread(ponyStart);
        ponyThread = new Thread(ponyMain);
        ponyThread.Start();
    }

    private void OnDisable()
    {
        pony.mode = -1;
    }

    // Update is called once per frame
    void Update ()
    {
        try
        {
            currentQuaternion = pony.quaternion;
            gameObject.transform.rotation = new Quaternion(currentQuaternion[1], currentQuaternion[2], currentQuaternion[3], currentQuaternion[0]);
        }
        catch
        {
            gameObject.transform.rotation = new Quaternion(0, 0, 0, 1);
        }
	}

    private void FixedUpdate()
    {
        acceleration = Input.acceleration;
        gyroscope = Input.gyro.attitude.eulerAngles;
    }

    void filterUpdate(float[] q, float w_x, float w_y, float w_z, float a_x, float a_y, float a_z, float deltat)
    {
        //float SEq_1 = 1.0f, SEq_2 = 0.0f, SEq_3 = 0.0f, SEq_4 = 0.0f; //estimated orientation quaternion elements with initial conditions
        // Local system variables
        float norm; // vector norm
        float SEqDot_omega_1, SEqDot_omega_2, SEqDot_omega_3, SEqDot_omega_4; // quaternion derrivative from gyroscopes elements
        float f_1, f_2, f_3; // objective function elements
        float J_11or24, J_12or23, J_13or22, J_14or21, J_32, J_33; //objective function Jacobian elements

        float SEqHatDot_1, SEqHatDot_2, SEqHatDot_3, SEqHatDot_4;
        // estimated direction of the gyroscope error
        // Axulirary variables to avoid reapeated calcualtions
        float halfSEq_1 = 0.5f * q[0];
        float halfSEq_2 = 0.5f * q[1];
        float halfSEq_3 = 0.5f * q[2];
        float halfSEq_4 = 0.5f * q[3];
        float twoSEq_1 = 2.0f * q[0];
        float twoSEq_2 = 2.0f * q[1];
        float twoSEq_3 = 2.0f * q[2];
        // Normalise the accelerometer measurement
        norm = (float)Math.Sqrt(a_x * a_x + a_y * a_y + a_z * a_z);
        a_x /= norm;
        a_y /= norm;
        a_z /= norm;
        // Compute the objective function and Jacobian
        f_1 = twoSEq_2 * q[3] - twoSEq_1 * q[2] - a_x;
        f_2 = twoSEq_1 * q[1] + twoSEq_3 * q[3] - a_y;
        f_3 = 1.0f - twoSEq_2 * q[1] - twoSEq_3 * q[2] - a_z;
        J_11or24 = twoSEq_3; // J_11 negated in matrix multiplication
        J_12or23 = 2.0f * q[3];
        J_13or22 = twoSEq_1; // J_12 negated in matrix multiplication
        J_14or21 = twoSEq_2;
        J_32 = 2.0f * J_14or21; // negated in matrix multiplication
        J_33 = 2.0f * J_11or24; // negated in matrix multiplication

        // Compute the gradient (matrixmultiplication)
        SEqHatDot_1 = J_14or21 * f_2 - J_11or24 * f_1;
        SEqHatDot_2 = J_12or23 * f_1 + J_13or22 * f_2 - J_32 * f_3;
        SEqHatDot_3 = J_12or23 * f_2 - J_33 * f_3 - J_13or22 * f_1;
        SEqHatDot_4 = J_14or21 * f_1 + J_11or24 * f_2;
        // Normalise the gradient
        norm = (float)Math.Sqrt(SEqHatDot_1 * SEqHatDot_1 + SEqHatDot_2 *
            SEqHatDot_2 + SEqHatDot_3 * SEqHatDot_3 + SEqHatDot_4 *
            SEqHatDot_4);
        SEqHatDot_1 /= norm;
        SEqHatDot_2 /= norm;
        SEqHatDot_3 /= norm;
        SEqHatDot_4 /= norm;
        // Compute the quaternion derrivative measured by gyroscopes
        SEqDot_omega_1 = -halfSEq_2 * w_x - halfSEq_3 * w_y -

            halfSEq_4 * w_z;
        SEqDot_omega_2 = halfSEq_1 * w_x + halfSEq_3 * w_z -
            halfSEq_4 * w_y;
        SEqDot_omega_3 = halfSEq_1 * w_y - halfSEq_2 * w_z +
            halfSEq_4 * w_x;
        SEqDot_omega_4 = halfSEq_1 * w_z + halfSEq_2 * w_y -
            halfSEq_3 * w_x;
        // Compute then integrate the estimated quaternion derrivative
        q[0] += (SEqDot_omega_1 - (beta * SEqHatDot_1)) * deltat;
        q[1] += (SEqDot_omega_2 - (beta * SEqHatDot_2)) * deltat;
        q[2] += (SEqDot_omega_3 - (beta * SEqHatDot_3)) * deltat;
        q[3] += (SEqDot_omega_4 - (beta * SEqHatDot_4)) * deltat;
        // Normalise quaternion
        norm = (float)Math.Sqrt(q[0] * q[0] + q[1] * q[1] + q[2] * q[2] + q[3] * q[3]);
        q[0] /= norm;
        q[1] /= norm;
        q[2] /= norm;
        q[3] /= norm;

    }


    void ponyMain()
    {
        pony = new LocalPony();
        pony.mode = 1;
        pony.quaternion = new float[]{ 1, 0, 0, 0 };
        stopwatch = new Stopwatch();

        float Mwx, Mwy, Mwz, Mfx, Mfy, Mfz, Afx, Afy, Afz;
        Mwx = 1.9937f;
        Mwy = 2.1801f;
        Mwz = 2.2016f;
        Mfx = 2.0019f;
        Afx = -254.4204f;
        Mfy = 2.0015f;
        Afy = 261.7441f;
        Mfz = 2.0009f;
        Afz = -260.9625f;
        //char* fileName = "newData.txt"; // ввести адрес файла
        //FILE* fpimu = fopen(fileName, "r");
        //FILE* fpout = fopen("out.txt", "w");//ввести адрес файла, куда будем записывать
        //char buffer[1024];
        float[] w = new float[3], f = new float[3];
        //int scanned;

        stopwatch.Start();
        //int lines_count = 0;
        while (pony.mode>-1)
        {
            timeInterval = stopwatch.ElapsedMilliseconds;
            
            stopwatch.Reset();
            stopwatch.Start();

            f[0] = acceleration.x;
            f[1] = acceleration.y;
            f[2] = acceleration.z;

            w[0] = gyroscope.x;
            w[1] = gyroscope.y;
            w[2] = gyroscope.z;
            //fgets(buffer, 1023, fpimu);

            //scanned = sscanf(buffer, "%*g %g %g %g  %g %g %g", &w[0], &w[1], &w[2], &f[0], &f[1], &f[2]);
            //if (scanned < 6)
            //    break;

            w[0] = (w[0] * M_PI) / (Mwx * 180);
            w[1] = (w[1] * M_PI) / (Mwy * 180);
            w[2] = (w[2] * M_PI) / (Mwz * 180);//gyroscope
            f[0] = (f[0] - Afx) / Mfx; //accelerometer
            f[1] = (f[1] - Afy) / Mfy;
            f[2] = (f[2] - Afz) / Mfz;

            filterUpdate(pony.quaternion, w[0], w[1], w[2], f[0], f[1], f[2], /*1/250f*/ stopwatch.ElapsedMilliseconds/1000f);

            //fprintf(fpout, "% +9.6f % +9.6f % +9.6f % +9.6f\n", q[0], q[1], q[2], q[3]);
        }

        //fclose(fpimu);
        //fclose(fpout);
    }
}
